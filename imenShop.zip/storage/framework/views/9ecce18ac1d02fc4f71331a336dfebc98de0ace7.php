<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?php echo $titles; ?></title>
</head>
<body>
    <p>
        <?php echo $messages; ?>

    </p>
</body>
</html>
<?php /**PATH D:\Installed\www\digimall\resources\views/email/index.blade.php ENDPATH**/ ?>