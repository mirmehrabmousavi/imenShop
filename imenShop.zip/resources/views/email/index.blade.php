<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>{!! $titles !!}</title>
</head>
<body>
    <p>
        {!!$messages!!}
    </p>
</body>
</html>
